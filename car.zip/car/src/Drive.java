public interface Drive {

    void turnOn();

    int increaseSpeed(int speed);

    int decreaseSpeed(int speed);

    void stop();


}
